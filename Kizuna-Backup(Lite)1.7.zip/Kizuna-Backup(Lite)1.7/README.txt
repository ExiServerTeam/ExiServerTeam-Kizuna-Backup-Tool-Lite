 Kizuna-Backup LITE v1.7 の使い方

【日本語】

1. 基本的な使い方
Kizuna-Backup LITEは、設定ファイル不要でコマンドライン引数だけで動作するシンプルなバックアップツールです。

基本コマンド:
  ./kizuna-lite.sh <対象ディレクトリ> <user@host> <リモートパス>

例:
  ./kizuna-lite.sh /home/user/data backup@192.168.1.100 /backup/data

2. オプション

  -m, --mode sync|archive   バックアップ方式（デフォルト: sync）
  -k, --key <鍵ファイル>    SSH秘密鍵
  -p, --port <ポート>       SSHポート（デフォルト: 22）
  --dry-run                 シミュレーションモード（実際には転送しない）
  -h, --help                ヘルプ表示

syncモード: rsyncで差分バックアップ（高速・軽量）
archiveモード: tar.gzで圧縮バックアップ（SHA-256整合性チェック付き）

3. 実行例

  # syncモード（基本）
  ./kizuna-lite.sh /home/user/data backup@192.168.1.100 /backup/data

  # archiveモード（tar.gz圧縮）
  ./kizuna-lite.sh /var/www user@server.com /backup/www --mode archive

  # SSH秘密鍵・ポート指定
  ./kizuna-lite.sh /etc root@10.0.0.1 /backup/etc -k ~/.ssh/id_rsa -p 2222

  # ドライラン（シミュレーション）
  ./kizuna-lite.sh /home/user/data backup@192.168.1.100 /backup/data --dry-run

4. 必要な環境

  - Bash 4.0以上
  - 以下のコマンドがインストールされていること:
    ssh / rsync / tar / sha256sum / flock / awk / du
  - SSH接続にはパスワード認証ではなく鍵認証を使用してください

5. 注意事項

  - バックアップ先のディレクトリは自動で作成されます
  - 本ツールは自己責任でご使用ください

6. PRO版（有料）について

Kizuna-Backup PRO（500円）では、以下の高度な機能が利用できます。
 PRO版の詳細・購入: https://manage.booth.pm/items/8715719/edit

7. ライセンス

  本ツールはフリーソフトウェアです。
  改変・再配布は自由ですが、作者（shige）へのクレジット表記を必須とします。

作者：shige

※当ツールを使用してバックアップを行った結果、データの消失などの損害が発生した場合でも、一切の責任は負いかねますのでご了承ください。
※このツールを改変し再配布しても構いません。ただし、再配布の際は原作者である私の名前（shige）を必ず記載して下さい。

-------------------------------------------------------------------------------

How to Use Kizuna-Backup LITE v1.7

【English】

1. Basic Usage

Kizuna-Backup LITE is a simple backup tool that works with command-line arguments only (no configuration file required).

Basic command:
  ./kizuna-lite.sh <target_directory> <user@host> <remote_path>

Example:
  ./kizuna-lite.sh /home/user/data backup@192.168.1.100 /backup/data

2. Options

  -m, --mode sync|archive   Backup mode (default: sync)
  -k, --key <key_file>      SSH private key
  -p, --port <port>         SSH port (default: 22)
  --dry-run                 Simulation mode (does not actually transfer)
  -h, --help                Show help

sync mode: rsync differential backup (fast, lightweight)
archive mode: tar.gz compressed backup (with SHA-256 integrity check)

3. Examples

  # sync mode (basic)
  ./kizuna-lite.sh /home/user/data backup@192.168.1.100 /backup/data

  # archive mode (tar.gz compression)
  ./kizuna-lite.sh /var/www user@server.com /backup/www --mode archive

  # SSH private key and port specified
  ./kizuna-lite.sh /etc root@10.0.0.1 /backup/etc -k ~/.ssh/id_rsa -p 2222

  # Dry run (simulation)
  ./kizuna-lite.sh /home/user/data backup@192.168.1.100 /backup/data --dry-run

4. Requirements

  - Bash 4.0 or higher
  - The following commands must be installed:
    ssh / rsync / tar / sha256sum / flock / awk / du
  - SSH key authentication is required (password authentication is not supported)

5. Notes

  - The remote directory will be created automatically
  - This tool is provided as-is, use at your own risk

6. PRO Version (Paid)

Kizuna-Backup PRO (500 JPY) includes the following advanced features:

  PRO features:
  - Configuration file (INI) management
  - Generation management (daily/weekly/monthly)
  - GPG encryption
  - Slack/Discord notifications
  - cron automation
  - Installation manual
  - Email support (1 year)

  For details and purchase: https://example.com/kizuna-backup-pro

7. License

  This tool is free software.
  You are free to modify and redistribute it, but you must credit the original author (shige).

Author: shige

!Please note that we cannot be held responsible for any data loss or other damages caused by using this tool for backups.!
!You are free to modify and redistribute this tool. However, you must credit the original author (shige) upon redistribution.!